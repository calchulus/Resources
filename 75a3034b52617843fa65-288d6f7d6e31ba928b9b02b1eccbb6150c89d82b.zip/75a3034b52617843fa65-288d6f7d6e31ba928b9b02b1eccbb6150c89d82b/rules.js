{
    "rules": {
        ".read": true,
        // todo: add other user lists and only keep the username in users/ --> anyone with auth can get that list
        // add users_profile (email etc.), users_roles
        // user roles stored separately so we can keep it secure and only accessible (read & write) with uid
        "users": {
          ".read": "auth !== null",
          "$user_id": {
            //".read": "auth !== null", //  && ( auth.uid === $user_id )",
            ".write": "auth !== null && ( auth.uid === $user_id )"
          }
        },
        "users_private": {
          //".read": "auth !== null",
           ".write": "auth.uid === data.child('uid').val()",
          "$user_id": {
            ".read": "auth.uid === $user_id", //&& ( auth.uid === $user_id )",
            ".write": "auth.uid === $user_id"
          }
        },
        "users_roles": {
          ".read": "auth!== null", // any auth user can read
          ".write": "root.child('users_roles').child(auth.uid).child('role').val() === 'admin'" //'8dbe8740-3c05-491f-9a51-07f09ee67aec'" // only admin can write --> how can we get this uid from firebase and not hardcoded
        },
        "syncedValue": {
          ".read": true,
          ".write": true
        },
        "messages": {
          ".read": "auth != null", //"(data.child('visibility').val() === 'public')",
          ".write": "auth != null", // --> check who can delete messages?
          "$messageId": {
            // write rules 1. auth user can add data / 2. owner can edit / 3. admin can edit too
            ".write": "( !data.exists() && auth != null ) || ( newData.child('uid').val() === auth.uid ) || ( $messageId === auth.uid) ||
                (root.child('users_private').child(auth.uid).child('profile/role').val() === 'admin')" // only owner or admin can write, user = 10, moderator = 20, admin = 999
          }
        }
    }
}